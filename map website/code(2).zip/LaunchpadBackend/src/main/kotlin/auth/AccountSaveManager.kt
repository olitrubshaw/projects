package auth

import com.google.gson.Gson
import java.io.File
import java.io.IOException
import java.security.MessageDigest


object AccountSaveManager {

    val fileStorePath = "/home/djdisaster/code/launchpad/data/accounts/"

    private val GSON = Gson().newBuilder()
        .enableComplexMapKeySerialization()
        .setPrettyPrinting()
        .create()

    private val loadedAccounts = HashMap<String, Account>()

    fun getAccount(email: String): Account? {
        val file = File(fileStorePath + email)
        file.parentFile.mkdirs()


        if (!file.exists()) {
            System.out.println("ERROR: account does not exists.")
            return null
        }

        try {
            val line = file.readText(Charsets.UTF_8)
            loadAccountFromGson(line)
        } catch (e: IOException) {
            System.err.println("Could not load account, email: $email reason: ${e.message}")
            e.printStackTrace()
        }
        System.out.println("END2: " + loadedAccounts)
        System.out.println("ACC: ${loadedAccounts[email]}")
        return loadedAccounts[email]
    }

    private fun loadAccountFromGson(gson: String) {
        val account = GSON.fromJson(gson, Account::class.java)
        loadedAccounts[account.email] = account
        account.runOnAccountLoad()
    }

    fun isEmailInUse(email: String): Boolean {
        val file = File(fileStorePath + email)
        if (file.exists()) {
            return true
        }
        if (loadedAccounts.containsKey(email)) {
            return true
        }
        return false
    }

    fun saveAccount(account: Account) {
        val file = File(fileStorePath + account.email)
        file.parentFile.mkdirs()
        file.createNewFile()
        file.writeText(GSON.toJson(account))
    }

    fun createAccount(email: String, pass: String): Account {
        val hashedPassword = hash(pass)
        val account = Account(email, hashedPassword)
        account.runOnAccountLoad()
        loadedAccounts[email] = account
        saveAccount(account)
        return account
    }

    fun hash(toHash: String): String {
        val md = MessageDigest.getInstance("SHA-512")
        return String(md.digest(toHash.toByteArray(Charsets.UTF_8)))

    }

}