package auth

import getCurrentUnixTimestamp
import java.security.SecureRandom

data class Session(
    val accountEmail: String,
    val expiryTimeUnix: Long
)


object SessionManager {
    val sessions = mutableMapOf<String, Session>()

    fun createSession(account: Account): String {
        val sb = StringBuilder()
        val sr = SecureRandom()

        repeat(15) {
            sb.append(sr.nextInt())
        }
        val key = sb.toString()
        sessions[key] = Session(account.email, getCurrentUnixTimestamp() + 72000)
        System.out.println("Sessions: " + sessions)
        return key
    }

    fun getSession(sessionKey: String): Account? {
        System.out.println("GET: " + sessions[sessionKey])
        val session = sessions[sessionKey]?: return null
        if (session.expiryTimeUnix < getCurrentUnixTimestamp()) {
            System.out.println("Session expired: " + session.expiryTimeUnix)
            sessions.remove(sessionKey)
            return null
        }
        System.out.println("END")
        return getAccount(sessions[sessionKey]!!.accountEmail)
    }

    fun getAccount(email: String): Account? {
        return AccountSaveManager.getAccount(email)
    }


}
