package auth

import getCurrentUnixTimestamp

data class Ticket(
    val date: String,
    val startLocation: String,
    val endLocation: String
)

/**
 * An Account class serialisable by GSON
 */
class Account(
    val email: String,
    val passwordHash: String,
    var tickets: ArrayList<Ticket> = ArrayList()
) {

    @Transient
    var loadedDateUnix: Long = -1L

    fun runOnAccountLoad() {
        loadedDateUnix = getCurrentUnixTimestamp()
        if (tickets == null) {
            tickets = ArrayList()
        }
    }

    fun bookTicket(ticket: Ticket) {
        tickets.add(ticket)
    }

}