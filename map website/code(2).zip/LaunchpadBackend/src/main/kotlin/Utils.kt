
fun getCurrentUnixTimestamp(): Long {
    return System.currentTimeMillis() / 1000L;
}