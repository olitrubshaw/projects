import ResponseHandler
import org.http4k.core.HttpHandler
import org.http4k.core.Method
import org.http4k.core.Request
import org.http4k.core.Response
import org.http4k.core.Status
import org.http4k.core.cookie.Cookie
import org.http4k.core.cookie.SameSite
import org.http4k.core.cookie.cookie
import org.http4k.server.Undertow
import org.http4k.server.asServer
import java.nio.charset.StandardCharsets

fun main() {
    val app: HttpHandler = { request: Request ->
        val origin = request.header("Origin") ?: "https://djdisaster.uk"

        if (request.method == Method.OPTIONS) {
            Response(Status.OK)
                .header("Access-Control-Allow-Origin", origin)
                .header("Access-Control-Allow-Credentials", "true")
                .header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                .header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        } else {
            try {
                val check = request.uri.path.removePrefix("/")

                if (check == "site") {
                    val stream = object {}.javaClass.classLoader.getResourceAsStream("index.html")
                    val html = stream?.readBytes()?.toString(StandardCharsets.UTF_8) ?: ""

                    Response(Status.OK)
                        .header("Content-Type", "text/html; charset=utf-8")
                        .header("Access-Control-Allow-Origin", origin)
                        .header("Access-Control-Allow-Credentials", "true")
                        .header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                        .header("Access-Control-Allow-Headers", "Content-Type, Authorization")
                        .body(html)
                } else {
                    val result = ResponseHandler.handle(check, request)

                    var response = Response(result.status)
                        .header("Content-Type", "application/json")
                        .header("Access-Control-Allow-Origin", origin)
                        .header("Access-Control-Allow-Credentials", "true")
                        .header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                        .header("Access-Control-Allow-Headers", "Content-Type, Authorization")
                        .body(result.json)

                    result.cookies.forEach {
                        response = response.cookie(
                            Cookie(
                                name = it.key,
                                value = it.value,
                                path = "/",
                                httpOnly = true,
                                secure = true,
                                sameSite = SameSite.None
                            )
                        )
                    }

                    response
                }
            } catch (e: Exception) {
                e.printStackTrace()

                Response(Status.INTERNAL_SERVER_ERROR)
                    .header("Content-Type", "application/json")
                    .header("Access-Control-Allow-Origin", origin)
                    .header("Access-Control-Allow-Credentials", "true")
                    .header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                    .header("Access-Control-Allow-Headers", "Content-Type, Authorization")
                    .body("""{"result":"error","message":"Internal server error"}""")
            }
        }
    }

    app.asServer(Undertow(8080)).start()
}