import auth.Account
import auth.AccountSaveManager
import auth.SessionManager
import auth.Ticket
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import org.http4k.core.Request
import org.http4k.core.Status
import org.http4k.core.cookie.cookie
import org.http4k.core.cookie.cookies

val GSON: Gson = GsonBuilder().setPrettyPrinting().create()

object ResponseHandler {

    private val routes = mapOf<String, Route>(
        "isAuthRoute" to IsAuthRoute(),
        "createAccount" to CreateAccountRoute(),
        "login" to LoginAccountRoute(),
        "bookTicket" to BookTicketRoute(),
        "tickets" to TicketsRoute()
    )

    fun handle(s: String, req: Request): RouteResponse {
        val split = s.split("/", limit = 2)
        val route = routes[split[0]] ?: return RouteResponse("invalid")
        return if (split.size == 1) {
            route.handle("", req)
        } else {
            route.handle(split[1], req)
        }
    }
}

interface Route {
    fun handle(s: String, req: Request): RouteResponse
}

data class SimpleTextResult(val result: String)
data class CookieResponse(val key: String, val value: String)

data class BookTicketRequest(
    val date: String,
    val startLocation: String,
    val endLocation: String
)

data class TicketsResult(
    val result: String,
    val tickets: List<Ticket>
)

data class ErrorResult(
    val result: String,
    val message: String
)

data class RouteResponse(
    val json: String,
    val cookies: ArrayList<CookieResponse> = ArrayList(),
    var status: Status = Status.OK
) {
    fun setCookie(key: String, value: String): RouteResponse {
        cookies.add(CookieResponse(key, value))
        return this
    }

    fun setStatus(status: Status): RouteResponse {
        this.status = status
        return this
    }
}

fun getAccountFromRequest(req: Request): Account? {
    val token = req.cookie("sessionToken") ?: return null
    return SessionManager.getSession(token.value)
}

class IsAuthRoute : Route {
    override fun handle(s: String, req: Request): RouteResponse {
        val t = req.cookie("sessionToken")
        System.out.println("C: " + req.cookies())
        var result = "not_auth"
        if (t != null) {
            val test = t.value
            val account = SessionManager.getSession(test)
            if (account == null) {
                result = "not_auth"
            } else {
                result = "auth"
            }
        }
        return RouteResponse(GSON.toJson(SimpleTextResult(result)))
    }
}

class CreateAccountRoute : Route {
    override fun handle(s: String, req: Request): RouteResponse {
        System.out.println("email: " + s)
        val split = s.split("/", limit = 3)
        if (split.size != 2) {
            return RouteResponse(GSON.toJson(SimpleTextResult("Invalid amount of parameters")))
                .setStatus(Status.INTERNAL_SERVER_ERROR)
        }

        val email = split[0]
        val pass = split[1]

        if (AccountSaveManager.isEmailInUse(email)) {
            return RouteResponse(GSON.toJson(SimpleTextResult("Email is in use")))
                .setStatus(Status.INTERNAL_SERVER_ERROR)
        }

        val account = AccountSaveManager.createAccount(email, pass)
        val session = SessionManager.createSession(account)

        return RouteResponse(GSON.toJson(SimpleTextResult("authenticated")))
            .setCookie("sessionToken", session)
    }
}

class LoginAccountRoute : Route {
    override fun handle(s: String, req: Request): RouteResponse {
        System.out.println("email: " + s)
        val split = s.split("/", limit = 3)
        if (split.size != 2) {
            return RouteResponse(GSON.toJson(SimpleTextResult("Invalid amount of parameters")))
                .setStatus(Status.INTERNAL_SERVER_ERROR)
        }

        val email = split[0]
        val pass = split[1]

        val acc =
            AccountSaveManager.getAccount(email) ?:
            return RouteResponse(GSON.toJson(SimpleTextResult("Invalid Email!")))
                .setStatus(Status.INTERNAL_SERVER_ERROR)

        if (acc.passwordHash != AccountSaveManager.hash(pass)) {
            return RouteResponse(GSON.toJson(SimpleTextResult("Invalid Password!")))
                .setStatus(Status.INTERNAL_SERVER_ERROR)
        }

        val session = SessionManager.createSession(acc)

        return RouteResponse(GSON.toJson(SimpleTextResult("authenticated")))
            .setCookie("sessionToken", session)
    }
}

class BookTicketRoute : Route {
    override fun handle(s: String, req: Request): RouteResponse {
        val account = getAccountFromRequest(req)
            ?: return RouteResponse(GSON.toJson(ErrorResult("error", "Not logged in")))
                .setStatus(Status.INTERNAL_SERVER_ERROR)

        val ticketRequest = try {
            GSON.fromJson(req.bodyString(), BookTicketRequest::class.java)
        } catch (e: Exception) {
            return RouteResponse(GSON.toJson(ErrorResult("error", "Invalid request")))
                .setStatus(Status.INTERNAL_SERVER_ERROR)
        }

        if (ticketRequest == null || ticketRequest.date.isBlank() || ticketRequest.startLocation.isBlank() || ticketRequest.endLocation.isBlank()) {
            return RouteResponse(GSON.toJson(ErrorResult("error", "Missing fields")))
                .setStatus(Status.INTERNAL_SERVER_ERROR)
        }

        if (ticketRequest.startLocation == ticketRequest.endLocation) {
            return RouteResponse(GSON.toJson(ErrorResult("error", "Start and end location cannot be the same")))
                .setStatus(Status.INTERNAL_SERVER_ERROR)
        }

        account.bookTicket(
            Ticket(
                ticketRequest.date,
                ticketRequest.startLocation,
                ticketRequest.endLocation
            )
        )

        AccountSaveManager.saveAccount(account)

        return RouteResponse(GSON.toJson(SimpleTextResult("success")))
    }
}

class TicketsRoute : Route {
    override fun handle(s: String, req: Request): RouteResponse {
        val account = getAccountFromRequest(req)
            ?: return RouteResponse(GSON.toJson(ErrorResult("error", "Not logged in")))
                .setStatus(Status.INTERNAL_SERVER_ERROR)

        return RouteResponse(
            GSON.toJson(
                TicketsResult(
                    "success",
                    account.tickets
                )
            )
        )
    }
}